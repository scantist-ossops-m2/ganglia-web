

If adding any minified third party JavaScript to
this repository, please keep a copy of the source/unminified
version here.

This is a mandatory for inclusion of this project in other
free software products and distributions.  It ensures
that it is always possible for people to modify any part
of the source or trace the origins of any component
in the project.


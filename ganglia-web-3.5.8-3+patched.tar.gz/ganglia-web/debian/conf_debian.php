<?php
if( file_exists( "/etc/ganglia-webfrontend/conf.php" ) ) {
  include_once "/etc/ganglia-webfrontend/conf.php";
}
?>
